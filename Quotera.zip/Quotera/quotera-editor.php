<?php
/**
 * Plugin Name: Quotera 
 * Description: Brings the world's most powerful and moving quotes right to your website or app. Perfect for bloggers, educators, and thought leaders who want to share words that resonate with your audience.
 * Version: 1.0.0
 * Author: Spencer Nelson
 */

if (!defined('ABSPATH')) {
    exit;
}

define('QUOTERA_PLUGIN_DIR', plugin_dir_path(__FILE__));

// Include logic
require_once QUOTERA_PLUGIN_DIR . 'includes/functions.php';
require_once QUOTERA_PLUGIN_DIR . 'admin/settings-page.php';

// Add admin menu for settings page
// (This is technically duplicated in your settings page file, so you can remove it from there or here)
function quotera_admin_menu() {
    add_menu_page(
        'Quotera Settings',    // Page title
        'Quotera',             // Menu title
        'manage_options',      // Capability
        'quotera',             // Menu slug
        'quotera_render_settings_page'  // Callback function
    );
}
add_action('admin_menu', 'quotera_admin_menu');

// Shortcode
function quotera_display_shortcode() {
    return quotera_get_quote_box();
}
add_shortcode('quotera_quote', 'quotera_display_shortcode');
