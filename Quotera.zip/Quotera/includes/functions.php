<?php
// API handling for api ninjas
function quotera_fetch_quote()
{
    $api_key = get_option('quotera_api_key', '');

    if (empty($api_key)) {
        return ['quote' => 'API key not configured.', 'author' => ''];
    }

    $url = 'https://api.api-ninjas.com/v1/quotes';
    $args = [
        'headers' => [
            'X-Api-Key' => $api_key
        ],
        'timeout' => 10
    ];

    $response = wp_remote_get($url, $args);

    if (is_wp_error($response)) {
        error_log('Quotera API error: ' . $response->get_error_message());
        return ['quote' => 'Failed to fetch quote.', 'author' => ''];
    }

    $body = json_decode(wp_remote_retrieve_body($response), true);

    if (!empty($body[0])) {
        return [
            'quote' => sanitize_text_field($body[0]['quote']),
            'author' => sanitize_text_field($body[0]['author'])
        ];
    }

    return ['quote' => 'No quote found.', 'author' => ''];
}

function quotera_get_quote_box()
{
    $quote_data = quotera_fetch_quote();
    ob_start();
    ?>
    <div class="quotera-box">
        <p class="quotera-quote">“<?php echo esc_html($quote_data['quote']); ?>”</p>
        <p class="quotera-author">– <?php echo esc_html($quote_data['author']); ?></p>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('quotera_quote', 'quotera_get_quote_box');
