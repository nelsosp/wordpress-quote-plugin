<?php
function quotera_render_settings_page()
{
    ?>
    <div class="wrap">
        <h1>Quotera Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('quotera_settings');  // Nonce + option group
            do_settings_sections('quotera');      // Sections and fields
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

function quotera_register_settings()
{
    register_setting('quotera_settings', 'quotera_api_key', [
        'sanitize_callback' => 'sanitize_text_field'
    ]);

    add_settings_section(
        'quotera_main',
        'API & Display Settings',
        null,
        'quotera'
    );

    add_settings_field(
        'quotera_api_key',
        'API Key',
        function () {
            $value = get_option('quotera_api_key', '');
            echo '<input type="password" name="quotera_api_key" value="' . esc_attr($value) . '" size="40">';
            echo '<p class="description">Enter your API key from <a href="https://api-ninjas.com" target="_blank">api-ninjas.com</a>.</p>';
        },
        'quotera',
        'quotera_main'
    );
}

add_action('admin_init', 'quotera_register_settings');
